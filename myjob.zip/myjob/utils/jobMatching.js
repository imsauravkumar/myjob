// Calculate match score between candidate and job
const calculateMatchScore = (candidate, job) => {
  let score = 0;
  let maxScore = 0;

  // Skills matching (40 points)
  maxScore += 40;
  if (candidate.profile?.skills && job.requirements?.skills) {
    const candidateSkills = candidate.profile.skills.map(s => s.toLowerCase());
    const jobSkills = job.requirements.skills.map(s => s.toLowerCase());
    const matchedSkills = jobSkills.filter(skill => 
      candidateSkills.some(cs => cs.includes(skill) || skill.includes(cs))
    );
    score += (matchedSkills.length / jobSkills.length) * 40;
  }

  // Resume skills matching (20 points)
  maxScore += 20;
  if (candidate.resume?.parsedData?.skills && job.requirements?.skills) {
    const resumeSkills = candidate.resume.parsedData.skills.map(s => s.toLowerCase());
    const jobSkills = job.requirements.skills.map(s => s.toLowerCase());
    const matchedSkills = jobSkills.filter(skill => 
      resumeSkills.some(rs => rs.includes(skill) || skill.includes(rs))
    );
    score += (matchedSkills.length / jobSkills.length) * 20;
  }

  // Experience matching (20 points)
  maxScore += 20;
  if (candidate.profile?.experience && job.requirements?.experience) {
    const candidateExp = candidate.profile.experience.toLowerCase();
    const jobExp = job.requirements.experience.toLowerCase();
    if (candidateExp.includes(jobExp) || jobExp.includes(candidateExp)) {
      score += 20;
    }
  }

  // Education matching (20 points)
  maxScore += 20;
  if (candidate.profile?.education && job.requirements?.education) {
    const candidateEdu = candidate.profile.education.toLowerCase();
    const jobEdu = job.requirements.education.toLowerCase();
    if (candidateEdu.includes(jobEdu) || jobEdu.includes(candidateEdu)) {
      score += 20;
    }
  }

  // Return percentage score
  return Math.round((score / maxScore) * 100);
};

module.exports = { calculateMatchScore };

