const express = require('express');
const Job = require('../models/Job');
const Application = require('../models/Application');
const User = require('../models/User');
const { auth, isAdmin } = require('../middleware/auth');

const router = express.Router();

// All admin routes require authentication and admin role
router.use(auth);
router.use(isAdmin);

// Get all jobs for moderation
router.get('/jobs', async (req, res) => {
  try {
    const jobs = await Job.find()
      .populate('employer', 'name email')
      .sort({ createdAt: -1 });
    res.json(jobs);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Approve/reject job
router.put('/jobs/:id/status', async (req, res) => {
  try {
    const { status } = req.body;
    const job = await Job.findByIdAndUpdate(
      req.params.id,
      { status },
      { new: true }
    );
    res.json(job);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get all users
router.get('/users', async (req, res) => {
  try {
    const users = await User.find().select('-password').sort({ createdAt: -1 });
    res.json(users);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get all applications
router.get('/applications', async (req, res) => {
  try {
    const applications = await Application.find()
      .populate('job')
      .populate('candidate', 'name email')
      .sort({ createdAt: -1 });
    res.json(applications);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get dashboard stats
router.get('/stats', async (req, res) => {
  try {
    const totalJobs = await Job.countDocuments();
    const activeJobs = await Job.countDocuments({ status: 'active' });
    const pendingJobs = await Job.countDocuments({ status: 'pending' });
    const totalUsers = await User.countDocuments();
    const totalApplications = await Application.countDocuments();
    const employers = await User.countDocuments({ role: 'employer' });
    const candidates = await User.countDocuments({ role: 'candidate' });

    res.json({
      totalJobs,
      activeJobs,
      pendingJobs,
      totalUsers,
      totalApplications,
      employers,
      candidates
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;

