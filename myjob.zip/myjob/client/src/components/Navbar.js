import React, { useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';

const Navbar = () => {
  const { user, logout } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <nav className="navbar">
      <div className="container">
        <Link to="/">Job Portal</Link>
        <div>
          {user ? (
            <>
              <Link to="/jobs">Jobs</Link>
              {user.role === 'candidate' && (
                <Link to="/candidate/dashboard">Dashboard</Link>
              )}
              {user.role === 'employer' && (
                <Link to="/employer/dashboard">Dashboard</Link>
              )}
              {user.role === 'admin' && (
                <Link to="/admin/panel">Admin Panel</Link>
              )}
              <span style={{ marginLeft: '20px', marginRight: '10px' }}>
                {user.name}
              </span>
              <button className="btn btn-secondary" onClick={handleLogout}>
                Logout
              </button>
            </>
          ) : (
            <>
              <Link to="/jobs">Jobs</Link>
              <Link to="/login">Login</Link>
              <Link to="/register">Register</Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;

