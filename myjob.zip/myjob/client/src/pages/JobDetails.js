import React, { useState, useEffect, useContext } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';

const JobDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useContext(AuthContext);
  const [job, setJob] = useState(null);
  const [coverLetter, setCoverLetter] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchJob();
  }, [id]);

  const fetchJob = async () => {
    try {
      const res = await axios.get(`/api/jobs/${id}`);
      setJob(res.data);
    } catch (error) {
      console.error('Error fetching job:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleApply = async (e) => {
    e.preventDefault();
    if (!user) {
      navigate('/login');
      return;
    }

    if (user.role !== 'candidate') {
      setMessage('Only candidates can apply for jobs');
      return;
    }

    try {
      await axios.post('/api/applications', {
        jobId: id,
        coverLetter
      });
      setMessage('Application submitted successfully!');
      setCoverLetter('');
    } catch (error) {
      setMessage(error.response?.data?.message || 'Failed to submit application');
    }
  };

  if (loading) {
    return <div className="container">Loading...</div>;
  }

  if (!job) {
    return <div className="container">Job not found</div>;
  }

  return (
    <div className="container">
      <div className="card">
        <h1>{job.title}</h1>
        <p><strong>Company:</strong> {job.company}</p>
        <p><strong>Location:</strong> {job.location}</p>
        <p><strong>Salary:</strong> {job.salary}</p>
        <p><strong>Type:</strong> {job.type}</p>
        <p><strong>Status:</strong> {job.status}</p>
        
        <h3 style={{ marginTop: '20px' }}>Description</h3>
        <p>{job.description}</p>

        {job.requirements && (
          <>
            <h3>Requirements</h3>
            {job.requirements.skills && (
              <p><strong>Skills:</strong> {job.requirements.skills.join(', ')}</p>
            )}
            {job.requirements.experience && (
              <p><strong>Experience:</strong> {job.requirements.experience}</p>
            )}
            {job.requirements.education && (
              <p><strong>Education:</strong> {job.requirements.education}</p>
            )}
          </>
        )}
      </div>

      {user && user.role === 'candidate' && job.status === 'active' && (
        <div className="card">
          <h2>Apply for this Job</h2>
          {message && (
            <div className={message.includes('success') ? 'alert alert-success' : 'alert alert-error'}>
              {message}
            </div>
          )}
          <form onSubmit={handleApply}>
            <div className="form-group">
              <label>Cover Letter (Optional)</label>
              <textarea
                value={coverLetter}
                onChange={(e) => setCoverLetter(e.target.value)}
                placeholder="Tell us why you're a good fit for this position..."
              />
            </div>
            <button type="submit" className="btn btn-primary">
              Submit Application
            </button>
          </form>
        </div>
      )}
    </div>
  );
};

export default JobDetails;

