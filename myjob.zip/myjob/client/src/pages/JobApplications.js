import React, { useState, useEffect, useContext } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';

const JobApplications = () => {
  const { jobId } = useParams();
  const { user } = useContext(AuthContext);
  const [applications, setApplications] = useState([]);
  const [job, setJob] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchApplications();
    fetchJob();
  }, [jobId]);

  const fetchApplications = async () => {
    try {
      const res = await axios.get(`/api/applications/job/${jobId}`);
      setApplications(res.data);
    } catch (error) {
      console.error('Error fetching applications:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchJob = async () => {
    try {
      const res = await axios.get(`/api/jobs/${jobId}`);
      setJob(res.data);
    } catch (error) {
      console.error('Error fetching job:', error);
    }
  };

  const handleStatusChange = async (applicationId, newStatus) => {
    try {
      await axios.put(`/api/applications/${applicationId}/status`, { status: newStatus });
      fetchApplications();
    } catch (error) {
      console.error('Error updating status:', error);
    }
  };

  if (loading) {
    return <div className="container">Loading...</div>;
  }

  return (
    <div className="container">
      <h1>Applications for {job?.title}</h1>
      
      {applications.length === 0 ? (
        <div className="card">
          <p>No applications yet for this job.</p>
        </div>
      ) : (
        <div>
          {applications.map(app => (
            <div key={app._id} className="card" style={{ marginBottom: '20px' }}>
              <h3>{app.candidate?.name}</h3>
              <p><strong>Email:</strong> {app.candidate?.email}</p>
              <p><strong>Status:</strong> {app.status}</p>
              <p><strong>Match Score:</strong> 
                <span className={`match-score ${
                  app.matchScore >= 70 ? 'high' : 
                  app.matchScore >= 40 ? 'medium' : 'low'
                }`}>
                  {app.matchScore}%
                </span>
              </p>
              {app.candidate?.profile?.skills && (
                <p><strong>Skills:</strong> {app.candidate.profile.skills.join(', ')}</p>
              )}
              {app.candidate?.profile?.experience && (
                <p><strong>Experience:</strong> {app.candidate.profile.experience}</p>
              )}
              {app.candidate?.profile?.education && (
                <p><strong>Education:</strong> {app.candidate.profile.education}</p>
              )}
              {app.coverLetter && (
                <div style={{ marginTop: '15px' }}>
                  <strong>Cover Letter:</strong>
                  <p style={{ marginTop: '5px', padding: '10px', background: '#f5f5f5', borderRadius: '5px' }}>
                    {app.coverLetter}
                  </p>
                </div>
              )}
              <p><strong>Applied:</strong> {new Date(app.createdAt).toLocaleDateString()}</p>
              
              <div style={{ marginTop: '15px' }}>
                <label><strong>Update Status:</strong></label>
                <select
                  value={app.status}
                  onChange={(e) => handleStatusChange(app._id, e.target.value)}
                  style={{ marginLeft: '10px', padding: '5px' }}
                >
                  <option value="pending">Pending</option>
                  <option value="reviewed">Reviewed</option>
                  <option value="shortlisted">Shortlisted</option>
                  <option value="rejected">Rejected</option>
                  <option value="accepted">Accepted</option>
                </select>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default JobApplications;

