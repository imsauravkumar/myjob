import React, { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';
import { Link } from 'react-router-dom';

const CandidateDashboard = () => {
  const { user } = useContext(AuthContext);
  const [profile, setProfile] = useState({
    phone: '',
    address: '',
    skills: [],
    experience: '',
    education: ''
  });
  const [applications, setApplications] = useState([]);
  const [message, setMessage] = useState('');

  useEffect(() => {
    if (user) {
      fetchProfile();
      fetchApplications();
    }
  }, [user]);

  const fetchProfile = async () => {
    try {
      const res = await axios.get('/api/users/profile');
      setProfile({
        phone: res.data.profile?.phone || '',
        address: res.data.profile?.address || '',
        skills: res.data.profile?.skills || [],
        experience: res.data.profile?.experience || '',
        education: res.data.profile?.education || ''
      });
    } catch (error) {
      console.error('Error fetching profile:', error);
    }
  };

  const fetchApplications = async () => {
    try {
      const res = await axios.get('/api/applications/my-applications');
      setApplications(res.data);
    } catch (error) {
      console.error('Error fetching applications:', error);
    }
  };

  const handleProfileUpdate = async (e) => {
    e.preventDefault();
    try {
      await axios.put('/api/users/profile', { profile });
      setMessage('Profile updated successfully!');
    } catch (error) {
      setMessage('Failed to update profile');
    }
  };

  const handleResumeUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('resume', file);

    try {
      const res = await axios.post('/api/users/resume', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      setMessage('Resume uploaded and parsed successfully!');
      fetchProfile();
    } catch (error) {
      setMessage('Failed to upload resume');
    }
  };

  const handleSkillAdd = () => {
    const skill = prompt('Enter a skill:');
    if (skill && !profile.skills.includes(skill)) {
      setProfile({
        ...profile,
        skills: [...profile.skills, skill]
      });
    }
  };

  const handleSkillRemove = (skill) => {
    setProfile({
      ...profile,
      skills: profile.skills.filter(s => s !== skill)
    });
  };

  return (
    <div className="container">
      <h1>Candidate Dashboard</h1>
      <p>Welcome, {user?.name}!</p>

      {message && (
        <div className={message.includes('success') ? 'alert alert-success' : 'alert alert-error'}>
          {message}
        </div>
      )}

      <div className="card">
        <h2>Profile Information</h2>
        <form onSubmit={handleProfileUpdate}>
          <div className="form-group">
            <label>Phone</label>
            <input
              type="text"
              value={profile.phone}
              onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
            />
          </div>
          <div className="form-group">
            <label>Address</label>
            <input
              type="text"
              value={profile.address}
              onChange={(e) => setProfile({ ...profile, address: e.target.value })}
            />
          </div>
          <div className="form-group">
            <label>Skills</label>
            <div style={{ marginBottom: '10px' }}>
              {profile.skills.map(skill => (
                <span
                  key={skill}
                  style={{
                    display: 'inline-block',
                    padding: '5px 10px',
                    margin: '5px',
                    background: '#007bff',
                    color: 'white',
                    borderRadius: '15px'
                  }}
                >
                  {skill}
                  <button
                    type="button"
                    onClick={() => handleSkillRemove(skill)}
                    style={{
                      marginLeft: '10px',
                      background: 'none',
                      border: 'none',
                      color: 'white',
                      cursor: 'pointer'
                    }}
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>
            <button type="button" className="btn btn-secondary" onClick={handleSkillAdd}>
              Add Skill
            </button>
          </div>
          <div className="form-group">
            <label>Experience</label>
            <input
              type="text"
              value={profile.experience}
              onChange={(e) => setProfile({ ...profile, experience: e.target.value })}
              placeholder="e.g., 5 years in software development"
            />
          </div>
          <div className="form-group">
            <label>Education</label>
            <input
              type="text"
              value={profile.education}
              onChange={(e) => setProfile({ ...profile, education: e.target.value })}
              placeholder="e.g., Bachelor's in Computer Science"
            />
          </div>
          <button type="submit" className="btn btn-primary">
            Update Profile
          </button>
        </form>
      </div>

      <div className="card">
        <h2>Upload Resume (PDF)</h2>
        <input
          type="file"
          accept=".pdf"
          onChange={handleResumeUpload}
          style={{ marginBottom: '10px' }}
        />
        <p style={{ fontSize: '14px', color: '#666' }}>
          Upload your resume in PDF format. We'll automatically parse it to extract your skills and experience.
        </p>
      </div>

      <div className="card">
        <h2>My Applications</h2>
        {applications.length === 0 ? (
          <p>You haven't applied to any jobs yet. <Link to="/jobs">Browse jobs</Link></p>
        ) : (
          <div>
            {applications.map(app => (
              <div key={app._id} style={{ marginBottom: '20px', padding: '15px', border: '1px solid #ddd', borderRadius: '5px' }}>
                <h3>{app.job?.title}</h3>
                <p><strong>Company:</strong> {app.job?.company}</p>
                <p><strong>Status:</strong> {app.status}</p>
                <p><strong>Match Score:</strong> 
                  <span className={`match-score ${
                    app.matchScore >= 70 ? 'high' : 
                    app.matchScore >= 40 ? 'medium' : 'low'
                  }`}>
                    {app.matchScore}%
                  </span>
                </p>
                <p><strong>Applied:</strong> {new Date(app.createdAt).toLocaleDateString()}</p>
                <Link to={`/jobs/${app.job?._id}`} className="btn btn-primary">
                  View Job
                </Link>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default CandidateDashboard;

