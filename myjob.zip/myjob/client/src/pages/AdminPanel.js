import React, { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';

const AdminPanel = () => {
  const { user } = useContext(AuthContext);
  const [stats, setStats] = useState(null);
  const [jobs, setJobs] = useState([]);
  const [applications, setApplications] = useState([]);
  const [users, setUsers] = useState([]);
  const [activeTab, setActiveTab] = useState('stats');

  useEffect(() => {
    if (user && user.role === 'admin') {
      fetchStats();
      fetchJobs();
      fetchApplications();
      fetchUsers();
    }
  }, [user]);

  const fetchStats = async () => {
    try {
      const res = await axios.get('/api/admin/stats');
      setStats(res.data);
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  const fetchJobs = async () => {
    try {
      const res = await axios.get('/api/admin/jobs');
      setJobs(res.data);
    } catch (error) {
      console.error('Error fetching jobs:', error);
    }
  };

  const fetchApplications = async () => {
    try {
      const res = await axios.get('/api/admin/applications');
      setApplications(res.data);
    } catch (error) {
      console.error('Error fetching applications:', error);
    }
  };

  const fetchUsers = async () => {
    try {
      const res = await axios.get('/api/admin/users');
      setUsers(res.data);
    } catch (error) {
      console.error('Error fetching users:', error);
    }
  };

  const handleJobStatusChange = async (jobId, status) => {
    try {
      await axios.put(`/api/admin/jobs/${jobId}/status`, { status });
      fetchJobs();
    } catch (error) {
      console.error('Error updating job status:', error);
    }
  };

  if (!user || user.role !== 'admin') {
    return (
      <div className="container">
        <div className="alert alert-error">Access denied. Admin only.</div>
      </div>
    );
  }

  return (
    <div className="container">
      <h1>Admin Panel</h1>
      <p>Welcome, {user.name}!</p>

      <div style={{ marginBottom: '20px' }}>
        <button
          className={`btn ${activeTab === 'stats' ? 'btn-primary' : 'btn-secondary'}`}
          onClick={() => setActiveTab('stats')}
          style={{ marginRight: '10px' }}
        >
          Statistics
        </button>
        <button
          className={`btn ${activeTab === 'jobs' ? 'btn-primary' : 'btn-secondary'}`}
          onClick={() => setActiveTab('jobs')}
          style={{ marginRight: '10px' }}
        >
          Jobs
        </button>
        <button
          className={`btn ${activeTab === 'applications' ? 'btn-primary' : 'btn-secondary'}`}
          onClick={() => setActiveTab('applications')}
          style={{ marginRight: '10px' }}
        >
          Applications
        </button>
        <button
          className={`btn ${activeTab === 'users' ? 'btn-primary' : 'btn-secondary'}`}
          onClick={() => setActiveTab('users')}
        >
          Users
        </button>
      </div>

      {activeTab === 'stats' && stats && (
        <div className="card">
          <h2>Dashboard Statistics</h2>
          <div className="grid">
            <div className="card">
              <h3>Total Jobs</h3>
              <p style={{ fontSize: '32px', fontWeight: 'bold' }}>{stats.totalJobs}</p>
            </div>
            <div className="card">
              <h3>Active Jobs</h3>
              <p style={{ fontSize: '32px', fontWeight: 'bold', color: '#28a745' }}>{stats.activeJobs}</p>
            </div>
            <div className="card">
              <h3>Pending Jobs</h3>
              <p style={{ fontSize: '32px', fontWeight: 'bold', color: '#ffc107' }}>{stats.pendingJobs}</p>
            </div>
            <div className="card">
              <h3>Total Users</h3>
              <p style={{ fontSize: '32px', fontWeight: 'bold' }}>{stats.totalUsers}</p>
            </div>
            <div className="card">
              <h3>Employers</h3>
              <p style={{ fontSize: '32px', fontWeight: 'bold' }}>{stats.employers}</p>
            </div>
            <div className="card">
              <h3>Candidates</h3>
              <p style={{ fontSize: '32px', fontWeight: 'bold' }}>{stats.candidates}</p>
            </div>
            <div className="card">
              <h3>Total Applications</h3>
              <p style={{ fontSize: '32px', fontWeight: 'bold' }}>{stats.totalApplications}</p>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'jobs' && (
        <div className="card">
          <h2>All Jobs</h2>
          {jobs.length === 0 ? (
            <p>No jobs found.</p>
          ) : (
            <div>
              {jobs.map(job => (
                <div key={job._id} style={{ marginBottom: '20px', padding: '15px', border: '1px solid #ddd', borderRadius: '5px' }}>
                  <h3>{job.title}</h3>
                  <p><strong>Company:</strong> {job.company}</p>
                  <p><strong>Employer:</strong> {job.employer?.name}</p>
                  <p><strong>Status:</strong> {job.status}</p>
                  <div style={{ marginTop: '10px' }}>
                    <button
                      className="btn btn-success"
                      onClick={() => handleJobStatusChange(job._id, 'active')}
                      style={{ marginRight: '10px' }}
                      disabled={job.status === 'active'}
                    >
                      Approve
                    </button>
                    <button
                      className="btn btn-danger"
                      onClick={() => handleJobStatusChange(job._id, 'closed')}
                      disabled={job.status === 'closed'}
                    >
                      Close
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {activeTab === 'applications' && (
        <div className="card">
          <h2>All Applications</h2>
          {applications.length === 0 ? (
            <p>No applications found.</p>
          ) : (
            <div>
              {applications.map(app => (
                <div key={app._id} style={{ marginBottom: '20px', padding: '15px', border: '1px solid #ddd', borderRadius: '5px' }}>
                  <h3>{app.job?.title}</h3>
                  <p><strong>Candidate:</strong> {app.candidate?.name}</p>
                  <p><strong>Status:</strong> {app.status}</p>
                  <p><strong>Match Score:</strong> {app.matchScore}%</p>
                  <p><strong>Applied:</strong> {new Date(app.createdAt).toLocaleDateString()}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {activeTab === 'users' && (
        <div className="card">
          <h2>All Users</h2>
          {users.length === 0 ? (
            <p>No users found.</p>
          ) : (
            <div>
              {users.map(u => (
                <div key={u._id} style={{ marginBottom: '20px', padding: '15px', border: '1px solid #ddd', borderRadius: '5px' }}>
                  <h3>{u.name}</h3>
                  <p><strong>Email:</strong> {u.email}</p>
                  <p><strong>Role:</strong> {u.role}</p>
                  <p><strong>Joined:</strong> {new Date(u.createdAt).toLocaleDateString()}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default AdminPanel;

