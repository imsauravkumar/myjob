import React, { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';
import { Link } from 'react-router-dom';

const EmployerDashboard = () => {
  const { user } = useContext(AuthContext);
  const [jobs, setJobs] = useState([]);
  const [showJobForm, setShowJobForm] = useState(false);
  const [jobForm, setJobForm] = useState({
    title: '',
    description: '',
    company: '',
    location: '',
    salary: '',
    type: 'Full-time',
    requirements: {
      skills: [],
      experience: '',
      education: ''
    }
  });
  const [message, setMessage] = useState('');

  useEffect(() => {
    if (user) {
      fetchJobs();
    }
  }, [user]);

  const fetchJobs = async () => {
    try {
      const res = await axios.get('/api/jobs/employer/my-jobs');
      setJobs(res.data);
    } catch (error) {
      console.error('Error fetching jobs:', error);
    }
  };

  const handleJobSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('/api/jobs', jobForm);
      setMessage('Job posted successfully! It will be reviewed by admin.');
      setShowJobForm(false);
      setJobForm({
        title: '',
        description: '',
        company: '',
        location: '',
        salary: '',
        type: 'Full-time',
        requirements: {
          skills: [],
          experience: '',
          education: ''
        }
      });
      fetchJobs();
    } catch (error) {
      setMessage('Failed to post job');
    }
  };

  const handleSkillAdd = () => {
    const skill = prompt('Enter required skill:');
    if (skill && !jobForm.requirements.skills.includes(skill)) {
      setJobForm({
        ...jobForm,
        requirements: {
          ...jobForm.requirements,
          skills: [...jobForm.requirements.skills, skill]
        }
      });
    }
  };

  const handleSkillRemove = (skill) => {
    setJobForm({
      ...jobForm,
      requirements: {
        ...jobForm.requirements,
        skills: jobForm.requirements.skills.filter(s => s !== skill)
      }
    });
  };

  return (
    <div className="container">
      <h1>Employer Dashboard</h1>
      <p>Welcome, {user?.name}!</p>

      {message && (
        <div className={message.includes('success') ? 'alert alert-success' : 'alert alert-error'}>
          {message}
        </div>
      )}

      <div style={{ marginBottom: '20px' }}>
        <button className="btn btn-primary" onClick={() => setShowJobForm(!showJobForm)}>
          {showJobForm ? 'Cancel' : 'Post New Job'}
        </button>
      </div>

      {showJobForm && (
        <div className="card">
          <h2>Post a New Job</h2>
          <form onSubmit={handleJobSubmit}>
            <div className="form-group">
              <label>Job Title</label>
              <input
                type="text"
                value={jobForm.title}
                onChange={(e) => setJobForm({ ...jobForm, title: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label>Company</label>
              <input
                type="text"
                value={jobForm.company}
                onChange={(e) => setJobForm({ ...jobForm, company: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label>Location</label>
              <input
                type="text"
                value={jobForm.location}
                onChange={(e) => setJobForm({ ...jobForm, location: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label>Salary</label>
              <input
                type="text"
                value={jobForm.salary}
                onChange={(e) => setJobForm({ ...jobForm, salary: e.target.value })}
                placeholder="e.g., $50,000 - $70,000"
                required
              />
            </div>
            <div className="form-group">
              <label>Job Type</label>
              <select
                value={jobForm.type}
                onChange={(e) => setJobForm({ ...jobForm, type: e.target.value })}
              >
                <option value="Full-time">Full-time</option>
                <option value="Part-time">Part-time</option>
                <option value="Contract">Contract</option>
                <option value="Internship">Internship</option>
              </select>
            </div>
            <div className="form-group">
              <label>Description</label>
              <textarea
                value={jobForm.description}
                onChange={(e) => setJobForm({ ...jobForm, description: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label>Required Skills</label>
              <div style={{ marginBottom: '10px' }}>
                {jobForm.requirements.skills.map(skill => (
                  <span
                    key={skill}
                    style={{
                      display: 'inline-block',
                      padding: '5px 10px',
                      margin: '5px',
                      background: '#28a745',
                      color: 'white',
                      borderRadius: '15px'
                    }}
                  >
                    {skill}
                    <button
                      type="button"
                      onClick={() => handleSkillRemove(skill)}
                      style={{
                        marginLeft: '10px',
                        background: 'none',
                        border: 'none',
                        color: 'white',
                        cursor: 'pointer'
                      }}
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
              <button type="button" className="btn btn-secondary" onClick={handleSkillAdd}>
                Add Skill
              </button>
            </div>
            <div className="form-group">
              <label>Required Experience</label>
              <input
                type="text"
                value={jobForm.requirements.experience}
                onChange={(e) => setJobForm({
                  ...jobForm,
                  requirements: { ...jobForm.requirements, experience: e.target.value }
                })}
                placeholder="e.g., 3+ years"
              />
            </div>
            <div className="form-group">
              <label>Required Education</label>
              <input
                type="text"
                value={jobForm.requirements.education}
                onChange={(e) => setJobForm({
                  ...jobForm,
                  requirements: { ...jobForm.requirements, education: e.target.value }
                })}
                placeholder="e.g., Bachelor's degree"
              />
            </div>
            <button type="submit" className="btn btn-primary">
              Post Job
            </button>
          </form>
        </div>
      )}

      <div className="card">
        <h2>My Job Postings</h2>
        {jobs.length === 0 ? (
          <p>You haven't posted any jobs yet.</p>
        ) : (
          <div>
            {jobs.map(job => (
              <div key={job._id} style={{ marginBottom: '20px', padding: '15px', border: '1px solid #ddd', borderRadius: '5px' }}>
                <h3>{job.title}</h3>
                <p><strong>Company:</strong> {job.company}</p>
                <p><strong>Location:</strong> {job.location}</p>
                <p><strong>Status:</strong> {job.status}</p>
                <p><strong>Applications:</strong> {job.applications?.length || 0}</p>
                <div style={{ marginTop: '10px' }}>
                  <Link to={`/jobs/${job._id}`} className="btn btn-primary" style={{ marginRight: '10px' }}>
                    View Job
                  </Link>
                  <Link to={`/employer/job/${job._id}/applications`} className="btn btn-secondary">
                    View Applications ({job.applications?.length || 0})
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default EmployerDashboard;

