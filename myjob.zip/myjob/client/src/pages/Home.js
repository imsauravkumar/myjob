import React from 'react';
import { Link } from 'react-router-dom';
import { useContext } from 'react';
import { AuthContext } from '../context/AuthContext';

const Home = () => {
  const { user } = useContext(AuthContext);

  return (
    <div className="container">
      <div style={{ textAlign: 'center', padding: '50px 0' }}>
        <h1 style={{ fontSize: '48px', marginBottom: '20px' }}>
          Welcome to Job Portal
        </h1>
        <p style={{ fontSize: '20px', marginBottom: '30px', color: '#666' }}>
          Find your dream job or hire the best talent
        </p>
        {!user ? (
          <div>
            <Link to="/register" className="btn btn-primary" style={{ marginRight: '10px' }}>
              Get Started
            </Link>
            <Link to="/jobs" className="btn btn-secondary">
              Browse Jobs
            </Link>
          </div>
        ) : (
          <div>
            {user.role === 'candidate' && (
              <Link to="/candidate/dashboard" className="btn btn-primary">
                Go to Dashboard
              </Link>
            )}
            {user.role === 'employer' && (
              <Link to="/employer/dashboard" className="btn btn-primary">
                Go to Dashboard
              </Link>
            )}
            {user.role === 'admin' && (
              <Link to="/admin/panel" className="btn btn-primary">
                Go to Admin Panel
              </Link>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default Home;

